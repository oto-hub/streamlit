import streamlit as st
from urllib.request import urlopen
import json
from deep_translator import GoogleTranslator
from datetime import date, timedelta
from random import choice
from os import path

def main():
    API_KEY = 'BxovKYfmCAfRy9ADfwDZP5p2CwAkgeUtctb1QfkI'
    start_day = date(1995, 6, 16)
    end_day = date.today() - timedelta(1)
    
    if 'select_date' not in st.session_state:
        st.session_state.select_date = end_day
    if 'div_data' not in st.session_state:
        div_data = load_json()
        restart_day = end_day
        while restart_day not in div_data:
            restart_day -= timedelta(1)
            if restart_day <= start_day:
                restart_day = start_day
                break
        if restart_day != end_day:
            add_div_data(restart_day, end_day, div_data, API_KEY)
            save_json(div_data)
        st.session_state.div_data = div_data
    if 'explanation_data' not in st.session_state:
        st.session_state.explanation_data = None
    if 'last_getDay' not in st.session_state:
        st.session_state.last_getDay = None
    if 'd' not in st.session_state:
        st.session_state.d = 0
    
    st.title('NASAの天文写真アーカイブ')
    st.write('毎日、宇宙のさまざまな画像や動画が簡単な説明とともに紹介されます。')
    st.write('')
    st.write('正しく翻訳されない場合があります。')
    st.write('また、選択した日付は撮影された日付ではないことにご留意ください。')
    st.write('')
    st.write('')
    dispDateSelector(st.session_state.div_data)
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.session_state.select_date > start_day:
            st.button('前の日', on_click=prevDay, key='prev_button')
    with col2:
        st.button('ランダムな日付', on_click=randDay, args=(st.session_state.div_data, ), key='rand_button')
    with col3:
        if st.session_state.select_date < end_day:
            st.button('次の日', on_click=nextDay, key='next_button')
    st.header(st.session_state.div_data[st.session_state.select_date]['trans_title'])
    st.subheader(f'原題：{st.session_state.div_data[st.session_state.select_date]['title']}')
    media = ''
    if st.session_state.div_data[st.session_state.select_date].get('media_type') == 'image':
        media = '画像'
        st.image(st.session_state.div_data[st.session_state.select_date]['url'], caption=f'出典：{st.session_state.div_data[st.session_state.select_date].get('copyright', 'NASA')}')
    elif st.session_state.div_data[st.session_state.select_date].get('media_type') == 'video':
        media = '動画'
        st.video(st.session_state.div_data[st.session_state.select_date]['url'])
    else:
        st.error('この日付データには対応するメディアがありません')
    if st.session_state.last_getDay != None and st.session_state.last_getDay != st.session_state.select_date:
        st.session_state.explanation_data = None
        st.session_state.last_getDay = st.session_state.select_date
        st.session_state.d += 1
        if st.session_state.d != 1:
            st.session_state.d = 0
    trans_exp = st.segmented_control(f'{media}の説明', ['原文', '日本語訳'], key=st.session_state.d)
    with st.spinner('説明 読み込み中...'):
        if trans_exp != None:
            explanation(API_KEY)
            st.session_state.last_getDay = st.session_state.select_date
            if trans_exp == '原文':
                st.write(st.session_state.explanation_data.get('explanation', 'No explanation'))
            elif trans_exp == '日本語訳':
                st.write(st.session_state.explanation_data.get('trans_explanation', '説明が見つかりませんでした'))

def load_json(): # jsonファイルの中身を返す
    if not path.exists('division_data.json'):
        return {}
    try:
        with open('division_data.json', 'r', encoding='utf-8') as file:
            div_data = json.load(file)
            # キーを文字列からdatetime.date型に変換
            for key in list(div_data.keys()):
                date_key = date.fromisoformat(key)
                div_data[date_key] = div_data.pop(key)
        return div_data
    except Exception as e:
        st.error(f'JSONの読み込み中にエラーが発生しました。：{e}')
        return {}

def add_div_data(start, end, div_data, API_KEY): # APIにアクセスしデータを取得する
    try:
        while start <= end:
            current_end = min(start + timedelta(days=365), end)
            API_URL = f'https://api.nasa.gov/planetary/apod?api_key={API_KEY}&start_date={start}&end_date={current_end}'
            with urlopen(API_URL) as response:
                if response.getcode() == 200:
                    data = json.load(response)
                    for d in data:
                        date_key = date.fromisoformat(d['date'])
                        if date_key not in div_data:
                            entry = {'title':d['title'], 'trans_title':GoogleTranslator(source='en', target='ja').translate(d['title']), 'media_type':d['media_type']}
                            if 'copyright' in d:
                                entry['copyright'] = d['copyright']
                            if 'url' in d:
                                entry['url'] = d['url']
                            div_data[date_key] = entry
            start = current_end + timedelta(1)
    except Exception as e:
        if hasattr(e, 'code') and e.code == 429:
            st.error("リクエストが多すぎます。しばらく待ってからもう一度お試しください。")
        else:
            st.error(f"データ取得中にエラーが発生しました: {e}")

def save_json(div_data): # データをjsonファイルに保存する
    # キーをdatetime.date型から文字列に変換
    for key in list(div_data.keys()):
        date_key = key.strftime('%Y-%m-%d')
        div_data[date_key] = div_data.pop(key)
    with open('division_data.json', 'w', encoding='utf-8') as file:
        json.dump(div_data, file, indent=4)

def getYMD(div_data): # データから年月日を取得し返す
    years = set()
    for d in div_data.keys():
        years.add(d.year)
    months = {}
    for y in years:
        month_list = set()
        for d in div_data.keys():
            if y == d.year:
                month_list.add(d.month)
        months[y] = list(month_list)
    days = {}
    for y in years:
        days[y] = {}
        for m in months[y]:
            day_list = set()
            for d in div_data.keys():
                if y == d.year and m == d.month:
                    day_list.add(d.day)
            days[y][m] = list(day_list)
    return list(years), months, days

def dispDateSelector(div_data): # 年月日のセレクトボックスを作成、表示する
    years, months, days = getYMD(div_data)
    select_month = st.session_state.select_date.month
    select_day = st.session_state.select_date.day
    cal1, cal2, cal3 = st.columns(3)
    with cal1:
        year = st.selectbox('日付を選択してください', years, index=years.index(st.session_state.select_date.year), format_func=lambda x:f'{x}年', key='year_select')
    with cal2:
        if select_month not in months[year]:
            select_month = months[year][0]
        month = st.selectbox('月を選択', months[year], index=months[year].index(select_month), format_func=lambda x :f'{x}月', label_visibility='hidden', key='month_select')
    with cal3:
        if select_day not in days[year][month]:
            dif_day = list()
            for n in days[year][month]:
                dif_day.append(abs(st.session_state.select_date.day - n))
            select_day = days[year][month][dif_day.index(min(dif_day))]
        day = st.selectbox('日を選択', days[year][month], index=days[year][month].index(select_day), format_func=lambda x:f'{x}日', label_visibility='hidden', key='day_select')
    st.session_state.select_date = date(year, month, day)

def prevDay(): # 前の日をselect_dateに入れる
    st.session_state.select_date -= timedelta(days=1)

def randDay(div_data): # ランダムな日付をselect_dateに入れる
    st.session_state.select_date = choice(list(div_data.keys()))

def nextDay(): # 次の日をselect_dateに入れる
    st.session_state.select_date += timedelta(1)

def getExplanation(API_KEY, date): # 説明文を取得する
    explanation_data = {}
    with urlopen(f'https://api.nasa.gov/planetary/apod?api_key={API_KEY}&date={date}') as response:
        if response.getcode() == 200:
            data = json.load(response)
            entry = {'date':date.fromisoformat(data['date']), 'explanation':data['explanation'], 'trans_explanation':GoogleTranslator(source='en', target='ja').translate(data['explanation'])}
            explanation_data = entry
    return explanation_data

def explanation(API_KEY): # 説明文を取得して表示する
    if st.session_state.explanation_data == None or st.session_state.explanation_data.get('date') != st.session_state.select_date:
        st.session_state.explanation_data = getExplanation(API_KEY, st.session_state.select_date)

main()